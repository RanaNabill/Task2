<?php
//connection to connect file
require_once("connect.php");
// to connect with database
$smt=$conn->prepare('select * From info');
$smt->execute();
$data=$smt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--connect to css file-->
<link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<?php
// define of variables 
$id= $name=""; 
?>
<!--form to input data-->
<h1 class="h1">Complete the Form</h1>
<form class="f" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<!--for user to enter id-->
<b>ID:</b> 
<input type="text" name="id" value="<?php echo $id;?>">
  <br><br>
  <!--for user to enter name-->
  <b>Name:</b>
  <input type="text" name="name" value="<?php echo $name;?>">
  <br><br>
  <!--dropdown list for period-->
  <label for="period"><b>Choose the period:</b></label>
  <select name="period" id="period">
    <!--code to select period from database-->
    <?php foreach ($data as $row):?>
      <option><?=$row["period"]?></option>
      <?php endforeach?>
  </select>
  <br><br>
  <!--dropdown list for material-->
  <label for="material"><b>Choose the Material:</b></label>
  <select name="material" id="material">
    <!--code to select material from database-->
    <?php foreach ($data as $row):?>
      <option><?=$row["material"]?></option>
      <?php endforeach?>
  </select>
  <br><br>
  <!--search button-->
  <input type="submit" name="submit" value="Search">
</form>
<?php
// connect to table2 file
require_once("table2.php");
?>
</body>
</html>