<?php
if (isset($_POST["submit"])){
    $id2= $_POST['id'];
    $name2= $_POST['name'];
    $period= $_POST['period'];
    $material= $_POST['material'];
    // code to select data from database
    $query=$conn->prepare("select * From info WHERE id='$id2' or name_of_arch LIKE '%$name2%' or period='$period' or material='$material'");
    $query->execute();
    $data=$query->fetchAll();

    // table to show data
    foreach ($data as $row){
        echo "<table  class='table' border='1' cellpadding='10' cellspacing='0'>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Period</th>
                    <th>Material</th>
                </tr>
                <tr>
                <td>$row[id]</td>
                <td>$row[name_of_arch]</td>
                <td>$row[period]</td>
                <td>$row[material]</td>
                </tr>

        </table>";}
    }
?>